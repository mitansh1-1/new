# Instagram Login Page Clone

<a href="https://edlavio.github.io/Instagram/" align="center"> <h3>Preview 👀</h3> </a>
<a href="https://edlavio.github.io/Instagram/">
  <img src="https://user-images.githubusercontent.com/79201879/178122135-d0c92812-7743-4040-8681-190ccbdacdf4.png" alt="Instagram">
</a>

## Tecnologias utilizadas🚀:


* HTML
* CSS 
* JS

## About 

Este projecto aborda conceito sobre CSS Flexbox e responsividade.



